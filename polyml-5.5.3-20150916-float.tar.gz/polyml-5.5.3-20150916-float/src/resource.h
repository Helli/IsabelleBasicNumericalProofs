//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PolyML.rc
//
#define IDR_MENU                        101
#define IDD_ABOUT_POLYML                101
#define IDI_ICON                        102
#define ID_EDIT_COPY                    30002
#define ID_EDIT_PASTE                   30003
#define ID_RUN_INTERRUPT                40001
#define ID_HELP_ABOUT                   40002
#define ID_FILE_QUIT                    40003
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
