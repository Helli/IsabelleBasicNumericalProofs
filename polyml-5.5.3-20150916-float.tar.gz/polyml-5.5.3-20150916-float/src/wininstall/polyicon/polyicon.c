#include <windows.h>

// This is a dummy executable.  It's only needed because the installer
// needs an executable to hold the icon.
int __stdcall WinMain(HINSTANCE hI, HINSTANCE hP, LPSTR s, int n)
{
    return 0;
}
